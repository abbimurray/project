-- MySQL dump 10.13  Distrib 8.2.0, for macos14.0 (x86_64)
--
-- Host: localhost    Database: EVCharging
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chargers`
--

DROP TABLE IF EXISTS `chargers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chargers` (
  `chargerID` int NOT NULL AUTO_INCREMENT,
  `chargerType` varchar(50) NOT NULL,
  `stationID` int NOT NULL,
  `status` enum('Available','In-Use','Under Repair','Reserved') DEFAULT NULL,
  `kw` int NOT NULL,
  `costPerKWH` decimal(10,3) DEFAULT NULL,
  `sessionStartTime` datetime DEFAULT NULL,
  `currentUserId` int DEFAULT NULL,
  PRIMARY KEY (`chargerID`),
  KEY `stationID` (`stationID`),
  KEY `fk_chargers_users` (`currentUserId`),
  CONSTRAINT `chargers_ibfk_1` FOREIGN KEY (`stationID`) REFERENCES `charging_stations` (`stationID`),
  CONSTRAINT `fk_chargers_users` FOREIGN KEY (`currentUserId`) REFERENCES `customer_accounts` (`customerID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chargers`
--

LOCK TABLES `chargers` WRITE;
/*!40000 ALTER TABLE `chargers` DISABLE KEYS */;
INSERT INTO `chargers` VALUES (1,'ccs',3,'Available',150,0.682,NULL,NULL),(2,'chademo',3,'Available',70,0.682,NULL,NULL),(4,'ccs',2,'Available',200,0.682,NULL,NULL),(7,'chademo',2,'Available',70,0.682,NULL,NULL),(8,'ccs',2,'Available',70,0.682,NULL,NULL),(9,'ccs',2,'Available',200,0.682,NULL,NULL),(10,'ccs',4,'Available',50,0.682,NULL,NULL),(11,'ccs',5,'Available',100,0.682,NULL,NULL),(12,'chademo',5,'Available',100,0.682,NULL,NULL),(13,'ccs',5,'Available',70,0.682,NULL,NULL),(14,'chademo ',5,'Available',70,0.682,NULL,NULL),(15,'chademo ',6,'Available',50,0.682,NULL,NULL),(16,'ccs',6,'Available',100,0.682,NULL,NULL),(17,'ccs',7,'Available',100,0.682,NULL,NULL),(18,'chademo',7,'Available',50,0.682,NULL,NULL),(19,'ccs',8,'Available',100,0.682,NULL,NULL),(20,'chademo',8,'Available',70,0.682,NULL,NULL),(21,'chademo',9,'Available',70,0.682,NULL,NULL),(22,'ccs',9,'Available',100,0.682,NULL,NULL);
/*!40000 ALTER TABLE `chargers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charging_stations`
--

DROP TABLE IF EXISTS `charging_stations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `charging_stations` (
  `stationID` int NOT NULL AUTO_INCREMENT,
  `county` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `numberOfChargers` int DEFAULT NULL,
  PRIMARY KEY (`stationID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charging_stations`
--

LOCK TABLES `charging_stations` WRITE;
/*!40000 ALTER TABLE `charging_stations` DISABLE KEYS */;
INSERT INTO `charging_stations` VALUES (2,'kildare','Mayfield Services, M7 Junction 14, Monasterevin, Kildare. ',4),(3,'kildare','circle k, m9, kilcullen, co. kildare.',2),(4,'Carlow','Four Lakes Retail Park,Dublin Road,CArlow Town, Carlow.',1),(5,'Tipperary','Obama Plaza, M7 Junction23',4),(6,'Laois','Portlaoise pLaza, Exit 17, Portlaoise, Co.Laois',2),(7,'Kilkenny','Kilkenny retail park, springhill, Kilkenny',2),(8,'Kilkenny ','Inver Slieverue Junction, Rathpatrick, Kilkenny ',2),(9,'Waterford','Ballybricken green, Ballybricken, Waterford ',2);
/*!40000 ALTER TABLE `charging_stations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chargingTransactions`
--

DROP TABLE IF EXISTS `chargingTransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chargingTransactions` (
  `transactionID` int NOT NULL AUTO_INCREMENT,
  `startTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `energyConsumed` decimal(10,2) DEFAULT NULL,
  `rate` decimal(10,3) DEFAULT NULL,
  `totalCost` decimal(10,3) DEFAULT NULL,
  `chargerID` int DEFAULT NULL,
  `customerID` int DEFAULT NULL,
  PRIMARY KEY (`transactionID`),
  KEY `fk_customerID` (`customerID`),
  CONSTRAINT `fk_customerID` FOREIGN KEY (`customerID`) REFERENCES `customer_accounts` (`customerID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chargingTransactions`
--

LOCK TABLES `chargingTransactions` WRITE;
/*!40000 ALTER TABLE `chargingTransactions` DISABLE KEYS */;
INSERT INTO `chargingTransactions` VALUES (2,'2024-02-19 10:00:00','2024-02-19 10:30:00',16.00,0.682,10.990,1,8),(4,'2024-04-18 09:20:48','2024-04-18 09:32:56',14.00,0.682,9.550,7,8),(5,'2024-04-18 18:51:52','2024-04-18 19:01:53',8.50,0.682,5.800,10,8),(7,'2024-04-18 19:48:16','2024-04-18 19:51:42',3.00,0.682,2.046,10,8),(9,'2024-04-18 20:03:04','2024-04-18 20:10:02',6.00,0.682,4.092,10,8),(15,'2024-04-19 16:09:51','2024-04-19 16:10:58',1.40,0.682,0.955,7,8),(17,'2024-04-20 09:59:57','2024-04-20 10:04:57',16.00,0.682,10.912,9,8),(19,'2024-04-20 10:26:48','2024-04-20 10:28:39',1.50,0.682,1.023,10,8),(20,'2024-04-20 12:02:20','2024-04-20 12:02:37',0.00,0.682,0.000,7,8),(21,'2024-04-20 12:07:37','2024-04-20 12:09:44',8.00,0.682,5.456,4,8),(22,'2024-04-20 12:29:19','2024-04-20 12:39:37',11.90,0.682,8.116,2,8),(24,'2024-04-20 13:37:41','2024-04-20 13:44:25',5.50,0.682,3.751,10,8),(25,'2024-04-20 15:46:00','2024-04-20 15:46:15',0.00,0.682,0.000,10,8),(26,'2024-04-21 16:10:33','2024-04-21 16:11:45',1.40,0.682,0.955,2,8),(27,'2024-04-21 18:13:58','2024-04-21 18:43:53',25.00,0.682,17.050,18,8),(28,'2024-04-23 11:00:22','2024-04-23 11:00:41',1.00,0.682,0.682,19,8),(29,'2024-04-23 11:26:06','2024-04-23 11:26:21',0.00,0.682,0.000,10,8),(30,'2024-04-23 11:56:51','2024-04-23 12:02:21',6.30,0.682,4.297,13,7),(31,'2024-04-23 13:50:12','2024-04-23 13:51:40',2.00,0.682,1.364,16,12),(32,'2024-04-23 13:52:49','2024-04-23 13:55:52',2.50,0.682,1.705,10,12),(33,'2024-04-23 18:58:20','2024-04-23 19:06:21',6.50,0.682,4.433,15,17);
/*!40000 ALTER TABLE `chargingTransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_accounts`
--

DROP TABLE IF EXISTS `customer_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_accounts` (
  `customerID` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customerID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_accounts`
--

LOCK TABLES `customer_accounts` WRITE;
/*!40000 ALTER TABLE `customer_accounts` DISABLE KEYS */;
INSERT INTO `customer_accounts` VALUES (7,'sally','o\'brien','sallyb@mail.com','086 4528977','e93a76f0a58158a17b2801aafada8e4a6fd053a5d4955d5c9c4aea21040ba36b','TP/OocI7gHhrdHLwS+X64g=='),(8,'Frank','Martin','frank@mail.com','087 543 6710','9445600a36ea7e001c53e99b30be949357af32065781ce56d901b91faacd2246','naLSs6ahaXRn7W7sSUHZJw=='),(12,'majella','murphy','majella@mail.com','087 5342182','b4f7e3806c1a18983719148dadacd2bd935c85345cd5199f3b2d02390572f164','/gAmO3v+dAFkumYPuRP4cg=='),(15,'john','murphy','johnm@mail.com','087 635 277','fd7b5cd74463f51f4e66b809848c939ead6c415fe5c87ff15c385d12a68aa9c5','UtYunohsRdpMin4BI81QYg=='),(16,'sarah','halloran','sarah1@mail.com','085 652 1773','006b7197abec3240d311d5c09a095e50c0d1647211858044323becf60990206e','NNzUIiXbc+czC6xt//HiYQ=='),(17,'Lucy','Jones','LucyJ@mail.com','087 456 3772','f084c433db98f6a3ec439af023e43080821860f90eb189ecb47a2176dcd2239e','nKhcN92fEoVJQVXVLVIHKA==');
/*!40000 ALTER TABLE `customer_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PaymentMethods`
--

DROP TABLE IF EXISTS `PaymentMethods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PaymentMethods` (
  `PaymentMethodID` int NOT NULL AUTO_INCREMENT,
  `CustomerID` int NOT NULL,
  `CardNumber` varchar(16) DEFAULT NULL,
  `Expiry` varchar(7) DEFAULT NULL,
  `SecurityCode` varchar(4) DEFAULT NULL,
  `NameOnCard` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PaymentMethodID`),
  KEY `CustomerID` (`CustomerID`),
  CONSTRAINT `paymentmethods_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer_accounts` (`customerID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PaymentMethods`
--

LOCK TABLES `PaymentMethods` WRITE;
/*!40000 ALTER TABLE `PaymentMethods` DISABLE KEYS */;
INSERT INTO `PaymentMethods` VALUES (9,8,'9873427541234842','08/24','694','frank martin'),(10,8,'6785567889765432','08/26','678','frank '),(13,8,'7564738298765432','03/26','1234','f'),(14,8,'8765432187654321','04/26','9864','frank'),(15,8,'5463723891393748','01/28','435','frank m'),(16,8,'1235873294619435','06/27','582','frank m'),(17,8,'7564738567345321','04/28','234','frank'),(18,7,'6767676767676767','03/36','376','sally o\'brien'),(19,7,'1234567891298765','01/27','653','Sally'),(21,12,'5655555555555656','09/27','999','m'),(22,12,'8921217642919320','05/26','847','majella');
/*!40000 ALTER TABLE `PaymentMethods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `reservationID` int NOT NULL AUTO_INCREMENT,
  `status` varchar(50) NOT NULL,
  `stationID` int DEFAULT NULL,
  `chargerID` int DEFAULT NULL,
  `customerID` int NOT NULL,
  `reservationStartTime` datetime DEFAULT NULL,
  `reservationEndTime` datetime DEFAULT NULL,
  PRIMARY KEY (`reservationID`),
  KEY `stationID` (`stationID`),
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`stationID`) REFERENCES `charging_stations` (`stationID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES (10,'Reserved',2,9,8,'2024-04-20 21:00:00','2024-04-20 21:30:00'),(12,'Reserved',3,1,8,'2024-04-21 12:00:00','2024-04-21 12:30:00'),(13,'Reserved',3,1,8,'2024-04-22 12:30:00','2024-04-22 13:00:00'),(14,'Reserved',2,7,8,'2024-04-20 19:00:00','2024-04-20 19:30:00'),(18,'Reserved',9,21,7,'2024-04-24 11:00:00','2024-04-24 11:30:00'),(19,'Reserved',9,22,7,'2024-04-23 14:00:00','2024-04-23 14:30:00'),(20,'Reserved',5,14,12,'2024-04-23 15:00:00','2024-04-23 15:30:00');
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-26 11:10:37
